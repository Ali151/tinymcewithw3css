// toggle function
function myFunction2222 () {
 //   var x = document.getElementsById("mce_0_ifr").contentWindow.document.getElementById("Demo2222");
	var x = document.getElementById("Demo2222");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else {
        x.className = x.className.replace(" w3-show", "");
    }
    
}

//		alert('All scripts 222222222222.');
//      <script type="text/javascript" src="js/ourscript.js"></script>


// accordion function
function myFunction2223(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
//////////////////////////////////////////////

// active accordion function
function myFunction2224(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        x.previousElementSibling.className += " w3-red";
    } else { 
        x.className = x.className.replace(" w3-show", "");
        x.previousElementSibling.className = 
        x.previousElementSibling.className.replace(" w3-red", "");
    }
}
//////////////////////////////////////////////

function myAccFunc() {
    var x = document.getElementById("demoAcc");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        x.previousElementSibling.className += " w3-green";
    } else { 
        x.className = x.className.replace(" w3-show", "");
        x.previousElementSibling.className = 
        x.previousElementSibling.className.replace(" w3-green", "");
    }
}

function myDropFunc() {
    var x = document.getElementById("demoDrop");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        x.previousElementSibling.className += " w3-green";
    } else { 
        x.className = x.className.replace(" w3-show", "");
        x.previousElementSibling.className = 
        x.previousElementSibling.className.replace(" w3-green", "");
    }
}

//////////////////////////////////////////////
//// filter table
function myFunction2226() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput2226");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable2226");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
////////////////////////////////////////////////
//// list table

function myFunction2227() {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput2227");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL2227");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        if (li[i].innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}
////////////////////////////////////////////////
// Dropdown
function dropFunction2228() {
    var x = document.getElementById("myDIV2228");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else {
        x.className = x.className.replace(" w3-show", "");
    }
}

// Filter
function filterFunction2228() {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput2228");
    filter = input.value.toUpperCase();
    div = document.getElementById("myDIV2228");
    a = div.getElementsByTagName("a");
    for (i = 0; i < a.length; i++) {
        if (a[i].innerHTML.toUpperCase().indexOf(filter) > -1) {
            a[i].style.display = "";
        } else {
            a[i].style.display = "none";
        }
    }
}
////////////////////////////////////////////////
//////////// modal image gallery
function onClick2230(element) {  
	document.getElementById("img01").src = element.src;  
	document.getElementById("modal01").style.display = "block";}
////////////////////////////////////////////////	
////////////////////////////////////////////////
//////////// W3.CSS Lightbox gallery
function openModal() {
  document.getElementById('myModal').style.display = "block";
}

function closeModal() {
  document.getElementById('myModal').style.display = "none";
}

var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function currentDiv(n) {
  showDivs(slideIndex = n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > x.length) {slideIndex = 1}
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
     dots[i].className = dots[i].className.replace(" w3-opacity-off", "");

  }
  x[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " w3-opacity-off";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
////////////////////////////////////////////////
	///////////////// progress bar
function move2231() {
  var elem = document.getElementById("myBar2231");   
  var width = 20;
  var id = setInterval(frame, 10);
  function frame() {
    if (width >= 100) {
      clearInterval(id);
    } else {
      width++; 
      elem.style.width = width + '%'; 
      elem.innerHTML = width * 1  + '%';
    }
  }
}
////////////////////////////////////////////////
	///////////////// progress bar-2 outside
function move2232() {
  var elem = document.getElementById("myBar2232");   
  var width = 20;
  var id = setInterval(frame, 10);
  function frame() {
    if (width >= 100) {
      clearInterval(id);
    } else {
      width++; 
      elem.style.width = width + '%'; 
      document.getElementById("demo2232").innerHTML = width * 1  + '%';
    }
  }
}
////////////////////////////////////////////////
	///////////////// progress bar-3 pro
function move2233() {
  var elem = document.getElementById("myBar2233");   
  var width = 0;
  var id = setInterval(frame, 50);
  function frame() {
    if (width >= 100) {
      clearInterval(id);
      document.getElementById("myP").className = "w3-text-green w3-animate-opacity";
      document.getElementById("myP").innerHTML = "Successfully uploaded 10 photos!";
    } else {
      width++; 
      elem.style.width = width + '%'; 
      var num = width * 1 / 10;
      num = num.toFixed(0)
      document.getElementById("demo2233").innerHTML = num;
    }
  }
}
////////////////////////////////////////////////
///////////////// clickable dropdown
function myFunction2234() {
    var x = document.getElementById("Demo2234");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
////////////////////////////////////////////////
function myFunction2234b() {
    var x = document.getElementById("Demo2234b");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
////////////////////////////////////////////////
///////////////// w3css tabs
function openCity2235(cityName) {
    var i;
    var x = document.getElementsByClassName("city");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    document.getElementById(cityName).style.display = "block";  
}


////////////////////////////////////////////////
////// w3css closable tabs
function openCity2236(cityName) {
    var i;
    var x = document.getElementsByClassName("city2");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    document.getElementById(cityName).style.display = "block";  
}
////////////////////////////////////////////////
////// w3css active tabs
function openCity2237(evt, cityName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("city3");
  for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" w3-red", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " w3-red";
}
////////////////////////////////////////////////
////// w3css vertical tabs
function openCity2238(evt, cityName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("city4");
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" w3-red", ""); 
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " w3-red";
}

////////////////////////////////////////////////
////// w3css animated tabs
function openLink2239(evt, animName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("city5");
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
     tablinks[i].className = tablinks[i].className.replace(" w3-red", "");
  }
  document.getElementById(animName).style.display = "block";
  evt.currentTarget.className += " w3-red";
}
////////////////////////////////////////////////
////// w3css image tabs
function openImg2240(imgName) {
  var i, x;
  x = document.getElementsByClassName("picture");
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";
  }
  document.getElementById(imgName).style.display = "block";
}
////////////////////////////////////////////////
////// w3css nav dropdown
function myFunction2241() {
    var x = document.getElementById("demo2241");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
////////////////////////////////////////////////
////// w3css collapsing navbar
function myFunction2242() {
    var x = document.getElementById("demo2242");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
////////////////////////////////////////////////
////// w3css responsive navbar
function w3_open2243() {
    document.getElementById("mySidenav").style.display = "block";
}
function w3_close2243() {
    document.getElementById("mySidenav").style.display = "none";
}
////////////////////////////////////////////////
////// w3css open all navbar
function w3_open2244() {
    document.getElementById("mySidenav").style.width = "100%";
    document.getElementById("mySidenav").style.display = "block";
}
function w3_close2244() {
    document.getElementById("mySidenav").style.display = "none";
}
////////////////////////////////////////////////
////// w3css open navbar and page to right
function w3_open2245() {
  document.getElementById("main").style.marginLeft = "25%";
  document.getElementById("mySidenav").style.width = "25%";
  document.getElementById("mySidenav").style.display = "block";
  document.getElementById("openNav").style.display = 'none';
}
function w3_close2245() {
  document.getElementById("main").style.marginLeft = "0%";
  document.getElementById("mySidenav").style.display = "none";
  document.getElementById("openNav").style.display = "inline-block";
}
////////////////////////////////////////////////
////// w3css open navbar double
function openLeftMenu() {
    document.getElementById("leftMenu").style.display = "block";
}
function closeLeftMenu() {
    document.getElementById("leftMenu").style.display = "none";
}

function openRightMenu() {
    document.getElementById("rightMenu").style.display = "block";
}
function closeRightMenu() {
    document.getElementById("rightMenu").style.display = "none";
}
////////////////////////////////////////////////
////////////// sidenav dropdown and accordion menu
function myAccFunc2246() {
    var x = document.getElementById("demoAcc");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        x.previousElementSibling.className += " w3-green";
    } else { 
        x.className = x.className.replace(" w3-show", "");
        x.previousElementSibling.className = 
        x.previousElementSibling.className.replace(" w3-green", "");
    }
}

function myDropFunc2246() {
    var x = document.getElementById("demoDrop");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        x.previousElementSibling.className += " w3-green";
    } else { 
        x.className = x.className.replace(" w3-show", "");
        x.previousElementSibling.className = 
        x.previousElementSibling.className.replace(" w3-green", "");
    }
}
////////////////////////////////////////////////
/////////// w3css sidenav overlay
function w3_open2247() {
    document.getElementById("mySidenav").style.display = "block";
    document.getElementById("myOverlay").style.display = "block";
}
function w3_close2247() {
    document.getElementById("mySidenav").style.display = "none";
    document.getElementById("myOverlay").style.display = "none";
}
/////////////////////////////////////////////////
