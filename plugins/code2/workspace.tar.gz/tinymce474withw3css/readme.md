English:
Tinymce with w3.css, prepared as adding new plug-ins and small changing of official plug-ins to Tinymce.
You can find the changing list in "UPDATES.txt" file.

You can find  information about common features of Tinymce at "www.tinymce.com" is official website of tinymce. 
That's our changes info:
***You can add font-awesome icons to page with from menu Insert-Icons selection. (Adding to first character of the lines makes some mistake, you can add from the second character of the lines.) 
***W3css, W3css2 at menubar. Some w3.css examples added. You can try.
***Htmltags at menubar. Some HTML tags and span styles added. You can try.
***Four emocotions added to emicotion plug-in.
***You can change background of the page with Body Background Color button.
***We added some templates to Menu-Insert-Template.


Please open 474withw3css.html or indexEN.html  with a modern internet browser (Firefox Quantum 57.0.1 (64 bit), Chromium 62.0.3202.94 etc.) for trying...

If you wish you can visit this link for trying:
https://www.fullportal.org/WEBTASARIM/Tinymce/tinymce474withw3css/474withw3css.html

****************************************************************************************
Türkçe:
W3css ile Tinymce, Tinymce programına bazı yeni eklentiler kurarak ve bazı resmi eklentilerinde ufak değişiklikler yaparak hazırlanmıştır.
Yapılan değişikliklerin listesini "UPDATES.txt" dosyasında bulabilirsiniz.

Genel özellikler ile ilgili bilgiler, tinymce programının resmi internet sitesi olan "www.tinymce.com" adresinde mevcuttur.
Bizim eklentilerimizle yaptığımız değişiklikler ise şöyle:
***Menüden Ekle-Simgeler seçeneği ile dilediğiniz font-awesome simgesini sayfaya ekleyebilirsiniz. (Satırın ilk karakterine yazıldığında hata oluşuyor, ikinci karakterden itibaren ekleyebilirsiniz.)
***Menü barındaki W3css, W3css2. Bazı w3.css örnekleri eklendi. Bunları deneyebilirsiniz.
***Menü barındaki Htmltags. Some HTML tags and span styles added. You can try.
***Emicotion eklentisine dört adet ifade (emocotion) eklendi.
***Sayfa arkaplan rengi butonu ile sayfanın arkaplan rengini değiştirebilirsiniz. 
***Menüden Ekle-Taslak bölümüne yeni taslaklar eklendi.


Denemek için bir internet tarayıcısı (Firefox Quantum 57.0.1 (64 bit), Chromium 62.0.3202.94 gibi) ile 474withw3cssTR.html veya index.html dosyasını açabilirsiniz...

Dilerseniz denemek için şu linki ziyaret edebilirsiniz:
https://www.fullportal.org/WEBTASARIM/Tinymce/tinymce474withw3css/474withw3cssTR.html


